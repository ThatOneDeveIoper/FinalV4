﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundEffects : MonoBehaviour
{
  
public AudioSource levelMusic;
public AudioSource winSong;
public AudioSource loseSong;

public bool levelSong = true;
public bool WinSong = false;
public bool LoseSong = false;

void Start (){

}

void Update () {

}

public void LevelMusic()
{
  levelSong = true;
  WinSong = false;
  levelMusic.Play();

} 

public void WinSound()
{
   if (levelMusic.isPlaying)
   levelSong = false;
   {
       levelMusic.Stop();
   }
   if(!winSong.isPlaying && WinSong == false)
   {
       winSong.Play();
       WinSong = true;
   }
}

public void LoseSound()
{
   if (levelMusic.isPlaying)
   levelSong = false;
   {
       levelMusic.Stop();
   }
   if(!loseSong.isPlaying && LoseSong == false)
   {
       loseSong.Play();
       LoseSong = true;
   }
}

}







