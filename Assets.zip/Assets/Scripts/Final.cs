﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Final : MonoBehaviour
{
    public Transform ruby;   
    public float moveSpeed = 3.5f;
    public bool vertical;
    public float changeTime = 3.0f;
    private RubyController rubyController; 

    public ParticleSystem smokeEffect;
    
    public AudioClip robotFixed;

    Rigidbody2D rigidbody2D;
    float timer;
    int direction = 1;
    bool broken = true;
    
    Animator animator;
    
    AudioSource audioSource;
    private Vector2 movement;
    

    void Start()
    {
        rigidbody2D = this.GetComponent<Rigidbody2D>();
        timer = changeTime;
        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
   
   GameObject rubyControllerObject = GameObject.FindWithTag("RubyController");

       
        if (rubyControllerObject != null)
        {
            rubyController = rubyControllerObject.GetComponent<RubyController>(); 
             print ("yeet");
           
        }     

                    if (rubyController == null)
          rubyController.ChangeScore(1);
        {

            print ("Cannot find GameController Script!");

        }  

   
   
   
   
   
   
   
    }





    void Update()
    {
       
        if(!broken)
        {
            return;
        }

       {

        Vector3 direction = ruby.position - transform.position;
        direction.Normalize();
        movement = direction;


       }  
        
        timer -= Time.deltaTime;

        if (timer < 0)
        {
            direction = -direction;
            timer = changeTime;
        }
    }
    
    void FixedUpdate()
    {
        
        if(!broken)
        {
            return;
        }
        
        Vector2 position = rigidbody2D.position;
        moveCharacter(movement);
        
    }
    
    void OnCollisionEnter2D(Collision2D other)
    {
        RubyController player = other.gameObject.GetComponent<RubyController >();

        if (player != null)
        {
            player.ChangeHealth(-2);
        }
    }
    
    void moveCharacter(Vector2 direction) {
        rigidbody2D.MovePosition((Vector2)transform.position + (direction *moveSpeed * Time.deltaTime));
    }

    public void Fix()
    {
        broken = false;
        rigidbody2D.simulated = false;
        
        animator.SetTrigger("Fixed");
        
        smokeEffect.Stop();
           rubyController.ChangeScore(1);
           audioSource.Stop();
            audioSource.PlayOneShot(robotFixed);
          
    }
     void DestroyGameObject()
    {
        Destroy(gameObject);
    }
}